import pandas as pd
df=pd.read_csv('C:/Users/david/Desktop/datamining/Beijing.csv')
df=df.drop(columns=['No','year','month','day','hour','season','PM_Dongsi','PM_Dongsihuan','PM_Nongzhanguan','DEWP','PRES','cbwd','precipitation','Iprec'],axis=1)
df=df.rename({'PM_US Post':"美國預測",'HUMI':"濕度",'TEMP':"溫度",'Iws':"累積風速"},axis=1)
print(df)