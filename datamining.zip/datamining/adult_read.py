import pandas as pd
df=pd.read_csv('C:/Users/ASUS/Desktop/bank.csv')
print(df)