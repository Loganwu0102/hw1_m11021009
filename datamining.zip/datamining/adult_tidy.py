import pandas as pd
df=pd.read_csv('C:/Users/david/Desktop/adult.txt',header=None)
df=df.drop(columns=[0,1,2,3,4,6,7,8,10,11,12],axis=1)
df=df.rename({5:"婚姻狀況",9:"性別",13:"國家",14:"收入"},axis=1)
print(df)